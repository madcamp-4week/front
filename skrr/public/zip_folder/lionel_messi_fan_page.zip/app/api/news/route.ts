import { getNews } from '@/lib/data';
import { NextResponse } from 'next/server';

// This is an API route to get all news articles.
export async function GET() {
  const news = await getNews();
  return NextResponse.json(news);
}
