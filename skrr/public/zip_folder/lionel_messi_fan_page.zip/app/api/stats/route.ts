import { getStats } from '@/lib/data';
import { NextResponse } from 'next/server';

// This is an API route to get all career stats.
export async function GET() {
  const stats = await getStats();
  return NextResponse.json(stats);
}
