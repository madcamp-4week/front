'use client';

import Image from 'next/image';

interface ImageCardProps {
  src: string;
  alt: string;
}

export default function ImageCard({ src, alt }: ImageCardProps) {
  // In a real app, this could open a modal for a larger view.
  const handleClick = () => {
    console.log(`Image clicked: ${src}`);
  };

  return (
    <div 
      className="relative aspect-square rounded-lg overflow-hidden cursor-pointer group shadow-lg hover:shadow-xl transition-shadow duration-300"
      onClick={handleClick}
    >
      <Image 
        src={src} 
        alt={alt} 
        fill // Use modern `fill` prop.
        // The `sizes` prop is a performance best practice for `fill` images.
        // It helps the browser request the correctly-sized image for the user's viewport.
        sizes="(min-width: 1024px) 25vw, (min-width: 768px) 33vw, (min-width: 640px) 50vw, 100vw"
        className="object-cover group-hover:scale-110 transition-transform duration-500 ease-in-out"
      />
      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
        <p className="text-white text-lg font-bold opacity-0 group-hover:opacity-100 transition-opacity duration-300">View</p>
      </div>
    </div>
  );
}
