export interface Article {
  slug: string;
  title: string;
  content: string;
  date: string; // ISO date string format, e.g., '2023-10-30'
  image?: string;
}

export interface Stat {
  label: string;
  value: number | string;
}

export interface GalleryImage {
  src: string;
  alt: string;
}
