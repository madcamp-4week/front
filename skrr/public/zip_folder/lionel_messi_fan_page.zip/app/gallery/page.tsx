import { getGalleryImages } from '@/lib/data';
import ImageCard from '@/components/ImageCard';
import type { Metadata } from 'next';

// Add metadata for better SEO
export const metadata: Metadata = {
  title: 'Gallery',
  description: 'A gallery of photos from Lionel Messi\'s illustrious career.',
};

export default async function GalleryPage() {
  const images = await getGalleryImages();

  return (
    <div>
      <h1 className="text-4xl font-bold mb-8 text-center">Gallery</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {images.map((image) => (
          // Use a unique property from the data, like `src`, as the key.
          // This is more stable than using the index.
          <ImageCard key={image.src} src={image.src} alt={image.alt} />
        ))}
      </div>
    </div>
  );
}
