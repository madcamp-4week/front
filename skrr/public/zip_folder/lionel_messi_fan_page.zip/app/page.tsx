import Image from 'next/image';

export default function HomePage() {
  return (
    <div className="text-center">
      <h1 className="text-5xl font-bold mb-4">Welcome to the Lionel Messi Fan Page</h1>
      <p className="text-xl text-gray-300 mb-8">The ultimate place for fans of the GOAT.</p>
      <div className="relative w-full h-96 rounded-lg overflow-hidden shadow-2xl">
        <Image
          src="/images/messi-hero.jpg"
          alt="Lionel Messi celebrating a goal"
          fill // Use `fill` prop for responsive images that fill their parent container.
          className="object-cover" // Use Tailwind's object-fit utility instead of the deprecated objectFit prop.
          priority // This image is the Largest Contentful Paint (LCP), so prioritize its loading.
        />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <h2 className="text-4xl font-extrabold text-white">LEGEND</h2>
        </div>
      </div>
    </div>
  );
}
