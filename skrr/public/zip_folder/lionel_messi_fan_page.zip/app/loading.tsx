export default function Loading() {
  return (
    // Use role="status" for better accessibility, indicating a busy state to screen readers.
    <div className="flex justify-center items-center min-h-[60vh]" role="status">
      <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-blue-500" aria-hidden="true"></div>
      <span className="sr-only">Loading...</span>
    </div>
  );
}
