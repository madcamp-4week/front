import type { Stat } from '@/lib/types';

export default function StatItem({ label, value }: Stat) {
  return (
    <div className="bg-gray-800 p-6 rounded-lg text-center shadow-lg transition-transform hover:scale-105 hover:shadow-blue-500/40">
      <p className="text-xl text-gray-400 mb-2">{label}</p>
      <p className="text-4xl font-bold text-blue-400">{value}</p>
    </div>
  );
}
