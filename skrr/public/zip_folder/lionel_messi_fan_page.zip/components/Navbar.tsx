'use client'; // This must be a client component to use hooks like usePathname.

import Link from 'next/link';
import { usePathname } from 'next/navigation'; // Import the usePathname hook to detect the current page.

const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About' },
  { href: '/stats', label: 'Stats' },
  { href: '/gallery', label: 'Gallery' },
  { href: '/news', label: 'News' },
];

export default function Navbar() {
  const pathname = usePathname(); // Get the current path.

  return (
    // Make the navbar sticky for easy access while scrolling.
    <header className="bg-gray-800/80 backdrop-blur-sm shadow-md sticky top-0 z-50">
      <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-white hover:text-blue-400 transition-colors">
          Messi
        </Link>
        <ul className="flex items-center space-x-4 md:space-x-6">
          {navLinks.map((link) => {
            const isActive = pathname === link.href;
            return (
              <li key={link.href}>
                <Link
                  href={link.href}
                  // Dynamically apply styles for the active link to provide visual feedback to the user.
                  className={`text-base md:text-lg transition-colors px-3 py-2 rounded-md ${ 
                    isActive
                      ? 'text-white bg-blue-600 font-semibold'
                      : 'text-gray-300 hover:text-white hover:bg-gray-700'
                  }`}
                >
                  {link.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </header>
  );
}
