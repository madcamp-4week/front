import type { Article, Stat, GalleryImage } from './types';

// Mock data for news articles.
const newsData: Article[] = [
  {
    slug: 'world-cup-victory-2022',
    title: 'Argentina Wins the 2022 FIFA World Cup!',
    content: `In a thrilling final against France, Argentina, led by Lionel Messi, clinched the World Cup title. Messi scored twice and converted his penalty in the shootout, finally achieving the one major trophy that had eluded him.\n\nThe victory cemented his status as the greatest player of all time for many fans and pundits around the globe.`,
    date: '2022-12-18',
    image: '/images/gallery/wc-trophy.jpg',
  },
  {
    slug: 'messi-joins-inter-miami',
    title: 'Lionel Messi Makes Landmark Move to Inter Miami',
    content: `In a move that shocked the football world, Lionel Messi announced he would be joining Major League Soccer club Inter Miami.\n\nThe decision marks a new chapter in his illustrious career, bringing one of the world's biggest stars to American soccer. His arrival is expected to have a massive impact on the league's popularity and viewership.`,
    date: '2023-06-07',
    image: '/images/messi-hero.jpg',
  },
  {
    slug: 'eighth-ballon-dor',
    title: "Messi Claims Record-Extending Eighth Ballon d'Or",
    content: `Following his World Cup triumph, Lionel Messi was awarded his eighth Ballon d'Or, further extending his record.\n\nHe beat out competition from Erling Haaland and Kylian Mbappé to win the prestigious award, recognizing him as the best player in the world for the 2022-2023 season.`,
    date: '2023-10-30',
    image: '/images/gallery/ballon-dor.jpg',
  },
];

// Mock data for career statistics.
const statsData: Stat[] = [
  { label: "Ballon d'Or Wins", value: 8 },
  { label: 'Total Career Goals', value: 837 },
  { label: 'Total Career Assists', value: 373 },
  { label: 'FIFA World Cup Trophies', value: 1 },
  { label: 'Copa América Trophies', value: 1 },
  { label: 'UEFA Champions League Trophies', value: 4 },
  { label: 'Club Trophies', value: 44 },
  { label: 'Argentina Caps', value: 180 },
  { label: 'Argentina Goals', value: 106 },
];

// Mock data for the image gallery. Using unique image sources is important.
const galleryData: GalleryImage[] = [
  { src: '/images/gallery/wc-trophy.jpg', alt: 'Messi celebrating World Cup win' },
  { src: '/images/messi-hero.jpg', alt: 'Messi in Inter Miami kit' },
  { src: '/images/gallery/ballon-dor.jpg', alt: "Messi with Ballon d'Or trophy" },
  { src: '/images/gallery/free-kick.jpg', alt: 'Messi taking a free kick' },
  { src: '/images/gallery/barca-celebration.jpg', alt: 'Messi celebrating with teammates' },
  { src: '/images/gallery/dribble.jpg', alt: 'Messi dribbling past defenders' },
  { src: '/images/gallery/family.jpg', alt: 'Messi with his family' },
  { src: '/images/gallery/cl-trophy.jpg', alt: 'Messi lifting a trophy' },
];

// Simulate async data fetching with a delay.
export const getNews = async (): Promise<Article[]> => {
  // Sort news by date descending to show the latest first.
  const sortedNews = [...newsData].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  return new Promise(resolve => setTimeout(() => resolve(sortedNews), 300));
};

// More efficient function to get only the slugs for generateStaticParams.
export const getArticleSlugs = async (): Promise<{ slug: string }[]> => {
  return new Promise(resolve => 
    setTimeout(() => resolve(newsData.map(article => ({ slug: article.slug }))), 50)
  );
};

// More efficient function to get a single article by its slug.
export const getNewsBySlug = async (slug: string): Promise<Article | undefined> => {
  return new Promise(resolve => 
    setTimeout(() => resolve(newsData.find(a => a.slug === slug)), 150)
  );
};

export const getStats = async (): Promise<Stat[]> => {
  return new Promise(resolve => setTimeout(() => resolve(statsData), 300));
};

export const getGalleryImages = async (): Promise<GalleryImage[]> => {
  return new Promise(resolve => setTimeout(() => resolve(galleryData), 300));
};
