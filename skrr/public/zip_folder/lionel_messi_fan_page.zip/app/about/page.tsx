import type { Metadata } from 'next';

// Add metadata for better SEO
export const metadata: Metadata = {
  title: 'About',
};

export default function AboutPage() {
  return (
    <div>
      <h1 className="text-4xl font-bold mb-6">About Lionel Messi</h1>
      <div className="space-y-4 text-lg text-gray-300">
        <p>
          Lionel Andrés Messi, born on June 24, 1987, is an Argentine professional footballer who plays as a forward for and captains both Major League Soccer club Inter Miami and the Argentina national team.
        </p>
        <p>
          Widely regarded as one of the greatest players of all time, Messi has won a record eight Ballon d'Or awards, a record six European Golden Shoes, and in 2020 was named to the Ballon d'Or Dream Team. 
        </p>
        <p>
          He spent his entire professional career with Barcelona, where he won a club-record 34 trophies, including ten La Liga titles, seven Copa del Rey titles and the UEFA Champions League four times. With his country, he won the 2021 Copa América and the 2022 FIFA World Cup.
        </p>
        <h2 className="text-2xl font-semibold pt-4">Major Achievements</h2>
        <ul className="list-disc list-inside pl-4">
          <li>8 Ballon d'Or awards</li>
          <li>2022 FIFA World Cup Champion</li>
          <li>2021 Copa América Champion</li>
          <li>4 UEFA Champions League titles</li>
          <li>10 La Liga titles</li>
        </ul>
      </div>
    </div>
  );
}
