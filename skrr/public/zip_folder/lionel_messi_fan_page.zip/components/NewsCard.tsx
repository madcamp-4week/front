import Link from 'next/link';
import Image from 'next/image';
import type { Article } from '@/lib/types';

interface NewsCardProps {
  article: Article;
}

export default function NewsCard({ article }: NewsCardProps) {
  return (
    <Link href={`/news/${article.slug}`} className="block group">
      <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg group-hover:shadow-blue-500/50 transition-all duration-300 group-hover:scale-[1.02]">
        <div className="flex flex-col md:flex-row">
          {article.image && (
            <div className="relative w-full md:w-1/3 h-48 md:h-auto">
              <Image 
                src={article.image} 
                alt={article.title} 
                fill // Use modern `fill` prop.
                className="object-cover" // Use modern `className` for object-fit.
              />
            </div>
          )}
          <div className="p-6 flex-1">
            <h3 className="text-2xl font-bold mb-2 group-hover:text-blue-400 transition-colors">{article.title}</h3>
            <p className="text-gray-400 mb-4 text-sm">{new Date(article.date).toLocaleDateString('en-US', { dateStyle: 'long' })}</p>
            <p className="text-gray-300 line-clamp-3">{article.content}</p>
          </div>
        </div>
      </div>
    </Link>
  );
}
