export default function Footer() {
  return (
    <footer className="bg-gray-800 mt-auto py-6">
      <div className="container mx-auto text-center text-gray-400">
        <p>&copy; {new Date().getFullYear()} Lionel Messi Fan Page. All rights reserved.</p>
        <p className="text-sm mt-2">This is a fan-made website for educational purposes.</p>
      </div>
    </footer>
  );
}
