import { getStats } from '@/lib/data';
import StatItem from '@/components/StatItem';
import type { Metadata } from 'next';

// Add metadata for better SEO
export const metadata: Metadata = {
  title: 'Career Stats',
  description: 'Detailed statistics of Lionel Messi\'s career, including goals, assists, and trophies.',
};

export default async function StatsPage() {
  const stats = await getStats();

  return (
    <div>
      <h1 className="text-4xl font-bold mb-8 text-center">Career Statistics</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {stats.map((stat) => (
          <StatItem key={stat.label} label={stat.label} value={stat.value} />
        ))}
      </div>
    </div>
  );
}
