import { getNewsBySlug, getArticleSlugs } from '@/lib/data';
import { notFound } from 'next/navigation';
import Image from 'next/image';
import type { Metadata } from 'next';

// Define a type for the component props for clarity.
type NewsDetailPageProps = {
  params: { slug: string };
};

// Generate static pages for each news article at build time for performance.
export async function generateStaticParams() {
  const slugs = await getArticleSlugs();
  return slugs;
}

// Generate dynamic metadata for each article page for better SEO.
export async function generateMetadata({ params }: NewsDetailPageProps): Promise<Metadata> {
  const article = await getNewsBySlug(params.slug);

  if (!article) {
    return {
      title: 'Article Not Found',
    };
  }

  return {
    title: article.title,
    description: article.content.substring(0, 160), // Use the beginning of the article as the description.
  };
}

export default async function NewsDetailPage({ params }: NewsDetailPageProps) {
  // Fetch only the specific article needed, which is more efficient.
  const article = await getNewsBySlug(params.slug);

  if (!article) {
    notFound(); // Show a 404 page if the article doesn't exist.
  }

  return (
    <article className="max-w-4xl mx-auto">
      <h1 className="text-4xl md:text-5xl font-extrabold mb-4">{article.title}</h1>
      <p className="text-gray-400 mb-6">{new Date(article.date).toLocaleDateString('en-US', { dateStyle: 'long' })}</p>
      {article.image && (
        <div className="relative w-full h-96 mb-8 rounded-lg overflow-hidden">
          <Image 
            src={article.image} 
            alt={article.title} 
            fill // Use modern `fill` prop.
            className="object-cover" // Use modern `className` for object-fit.
            priority // Prioritize loading the main article image.
          />
        </div>
      )}
      {/* Use Tailwind Typography for clean article styling and preserve line breaks from the data source */}
      <div className="prose prose-invert prose-lg max-w-none text-gray-300 whitespace-pre-line">
        {article.content}
      </div>
    </article>
  );
}
