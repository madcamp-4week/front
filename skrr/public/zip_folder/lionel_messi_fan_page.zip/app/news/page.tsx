import { getNews } from '@/lib/data';
import NewsCard from '@/components/NewsCard';
import type { Metadata } from 'next';

// Add metadata for better SEO
export const metadata: Metadata = {
  title: 'News',
  description: 'The latest news and articles about Lionel Messi.',
};

export default async function NewsPage() {
  const articles = await getNews();

  return (
    <div>
      <h1 className="text-4xl font-bold mb-8">Latest News</h1>
      <div className="space-y-6">
        {articles.map((article) => (
          <NewsCard key={article.slug} article={article} />
        ))}
      </div>
    </div>
  );
}
